--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.1 (Debian 13.1-1.pgdg100+1)
-- Dumped by pg_dump version 13.1 (Debian 13.1-1.pgdg100+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE movies;
--
-- Name: movies; Type: DATABASE; Schema: -; Owner: root
--

CREATE DATABASE movies WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.utf8';


ALTER DATABASE movies OWNER TO root;

\connect movies

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: actors; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.actors (
    id integer NOT NULL,
    fname character varying(20),
    lname character varying(20)
);


ALTER TABLE public.actors OWNER TO root;

--
-- Name: actors_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.actors_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.actors_id_seq OWNER TO root;

--
-- Name: actors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.actors_id_seq OWNED BY public.actors.id;


--
-- Name: actorsmovies; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.actorsmovies (
    id integer NOT NULL,
    actor_id integer,
    movie_id integer
);


ALTER TABLE public.actorsmovies OWNER TO root;

--
-- Name: actorsmovies_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.actorsmovies_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.actorsmovies_id_seq OWNER TO root;

--
-- Name: actorsmovies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.actorsmovies_id_seq OWNED BY public.actorsmovies.id;


--
-- Name: directors; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.directors (
    id integer NOT NULL,
    fname character varying(20),
    lname character varying(20)
);


ALTER TABLE public.directors OWNER TO root;

--
-- Name: directors_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.directors_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.directors_id_seq OWNER TO root;

--
-- Name: directors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.directors_id_seq OWNED BY public.directors.id;


--
-- Name: movies; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.movies (
    id integer NOT NULL,
    name character varying(200),
    year smallint
);


ALTER TABLE public.movies OWNER TO root;

--
-- Name: movies_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.movies_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.movies_id_seq OWNER TO root;

--
-- Name: movies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.movies_id_seq OWNED BY public.movies.id;


--
-- Name: moviesdirectors; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.moviesdirectors (
    id integer NOT NULL,
    movie_id integer,
    director_id integer
);


ALTER TABLE public.moviesdirectors OWNER TO root;

--
-- Name: moviesdirectors_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.moviesdirectors_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.moviesdirectors_id_seq OWNER TO root;

--
-- Name: moviesdirectors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.moviesdirectors_id_seq OWNED BY public.moviesdirectors.id;


--
-- Name: actors id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.actors ALTER COLUMN id SET DEFAULT nextval('public.actors_id_seq'::regclass);


--
-- Name: actorsmovies id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.actorsmovies ALTER COLUMN id SET DEFAULT nextval('public.actorsmovies_id_seq'::regclass);


--
-- Name: directors id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.directors ALTER COLUMN id SET DEFAULT nextval('public.directors_id_seq'::regclass);


--
-- Name: movies id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.movies ALTER COLUMN id SET DEFAULT nextval('public.movies_id_seq'::regclass);


--
-- Name: moviesdirectors id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.moviesdirectors ALTER COLUMN id SET DEFAULT nextval('public.moviesdirectors_id_seq'::regclass);


--
-- Data for Name: actors; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.actors (id, fname, lname) FROM stdin;
\.
COPY public.actors (id, fname, lname) FROM '$$PATH$$/2977.dat';

--
-- Data for Name: actorsmovies; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.actorsmovies (id, actor_id, movie_id) FROM stdin;
\.
COPY public.actorsmovies (id, actor_id, movie_id) FROM '$$PATH$$/2983.dat';

--
-- Data for Name: directors; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.directors (id, fname, lname) FROM stdin;
\.
COPY public.directors (id, fname, lname) FROM '$$PATH$$/2981.dat';

--
-- Data for Name: movies; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.movies (id, name, year) FROM stdin;
\.
COPY public.movies (id, name, year) FROM '$$PATH$$/2979.dat';

--
-- Data for Name: moviesdirectors; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.moviesdirectors (id, movie_id, director_id) FROM stdin;
\.
COPY public.moviesdirectors (id, movie_id, director_id) FROM '$$PATH$$/2985.dat';

--
-- Name: actors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.actors_id_seq', 5, true);


--
-- Name: actorsmovies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.actorsmovies_id_seq', 6, true);


--
-- Name: directors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.directors_id_seq', 5, true);


--
-- Name: movies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.movies_id_seq', 6, true);


--
-- Name: moviesdirectors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.moviesdirectors_id_seq', 6, true);


--
-- Name: actors actors_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.actors
    ADD CONSTRAINT actors_pkey PRIMARY KEY (id);


--
-- Name: actorsmovies actorsmovies_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.actorsmovies
    ADD CONSTRAINT actorsmovies_pkey PRIMARY KEY (id);


--
-- Name: directors directors_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.directors
    ADD CONSTRAINT directors_pkey PRIMARY KEY (id);


--
-- Name: movies movies_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.movies
    ADD CONSTRAINT movies_pkey PRIMARY KEY (id);


--
-- Name: moviesdirectors moviesdirectors_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.moviesdirectors
    ADD CONSTRAINT moviesdirectors_pkey PRIMARY KEY (id);


--
-- Name: actorsmovies fk_actor; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.actorsmovies
    ADD CONSTRAINT fk_actor FOREIGN KEY (actor_id) REFERENCES public.actors(id);


--
-- Name: moviesdirectors fk_director; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.moviesdirectors
    ADD CONSTRAINT fk_director FOREIGN KEY (director_id) REFERENCES public.directors(id);


--
-- Name: actorsmovies fk_movie; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.actorsmovies
    ADD CONSTRAINT fk_movie FOREIGN KEY (movie_id) REFERENCES public.movies(id);


--
-- Name: moviesdirectors fk_movie; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.moviesdirectors
    ADD CONSTRAINT fk_movie FOREIGN KEY (movie_id) REFERENCES public.movies(id);


--
-- PostgreSQL database dump complete
--

